Usage: python assg1_42027249_42229904.py setup_file desired_output_file folder_name/path(for motion history and policy)

